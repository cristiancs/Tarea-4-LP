Integrantes:
Juan Pablo Jorquera Zapata       201573533-6
Cristian Andres Navarrete Galvez 201573549-2

Instrucciones:

Estos programas estan hechos para funcionar con DrRacket, para correrlos debe abrirlos en dr racket y presionar el boton ejecutar en la parte superior.